A=zeros(1,3);
for i=1:3
    A(i)=input('');
end
disp(issorted(A,'monotonic'));